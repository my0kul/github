﻿using System;
using System.Collections.Generic;
using System.IO;
using GTANetworkAPI;
namespace RedProject
{
    public class Animator : Script
    {

        [Flags]
        public enum AnimationFlags
        {
            Loop = 1 << 0,
            StopOnLastFrame = 1 << 1,
            OnlyAnimateUpperBody = 1 << 4,
            AllowPlayerControl = 1 << 5,
            Cancellable = 1 << 7
        }

        [RemoteEvent("ANIMATOR_EVENT")]
        public void AnimatorEventHandler(Player player, params object[] args)
        {
            if (Main.Players[player].LVL < 5) return;
            switch ((string)args[0])
            {
                case "Animator_PlayAnim": PlayAnimation(player, (string)args[1]); break;
            }
        }

        private void PlayAnimation(Player player, string anim)
        {
            if (Main.Players[player].LVL < 5) return;
            string[] animInfo = anim.ToString().Split(' ');
            player.SetData("PLAYED_ANIMATION_GROUP", animInfo[0]);
            player.SetData("PLAYED_ANIMATION_NAME", animInfo[1]);
            player.StopAnimation();
            player.PlayAnimation(animInfo[0], animInfo[1], (int)AnimationFlags.Loop);
        }

        [Command("animator", "====================[~b~ANIM~w~ATOR ~b~MANAGER]====================\n" +
            "Запустить: ~g~/animator start \n" +
            "~w~Помощь в использовании: ~g~/animator help \n" +
            "~w~Остановить анимацию: ~g~/animator stop \n" +
            "~w~Переключиться на анимацию: ~g~/animator skip [айди анимации]")]
        public void StartAnimator(Player player, string action = null, string action2 = "Anim")
        {
            if (Main.Players[player].LVL < 5) return;
            if (!player.HasData("ANIMATOR_OPEN")) player.SetData("ANIMATOR_OPEN", false);
            bool AnimatorOpen = player.GetData<bool>("ANIMATOR_OPEN");

            if (action == null)
            {
                if (!AnimatorOpen)
                {
                    player.SetData("ANIMATOR_OPEN", true);
                    player.TriggerEvent("StartClientAnimator");

                    int animIndex = 0;
                    List<string> temp = new List<string>();
                    foreach (string anim in AnimatorList.animations.AllAnimations)
                    {
                        temp.Add(anim);
                        animIndex++;

                        if (animIndex == 500)
                        {
                            player.TriggerEvent("AddAnimatorAnims", NAPI.Util.ToJson(temp));
                            animIndex = 0;
                            temp.Clear();
                        }

                    }
                    player.SendChatMessage("~b~[ANIMATOR MANAGER]: ~w~AnimatorManager сейчас ~g~ВКЛЮЧЕН~w~. Напишите ~g~/animator help ~w~чтобы получить помощь.");
                }
                else
                {
                    player.ResetData("ANIMATOR_OPEN");
                    player.TriggerEvent("StopClientAnimator");
                    player.StopAnimation();
                    player.SendChatMessage("~b~[ANIMATOR]: ~w~AnimatorManager сейчас ~r~ВЫКЛЮЧЕН~w~.");
                }
            }

            if (action != null && AnimatorOpen)
            {
                if (AnimatorOpen)
                {
                    if (action == "save") SaveAnimatorData(player, action2);
                    if (action == "skip") SkipAnimatorData(player, action2);
                    if (action == "help")
                    {
                        player.SendChatMessage("=================================[~b~ANIM~w~ATOR]================================");
                        player.SendChatMessage("Используйте ~y~LEFT ~w~и ~y~RIGHT ~w~стрелки на клавиатуре чтобы листать анимации.");
                        player.SendChatMessage("Используйте ~y~UP ~w~и ~y~DOWN ~w~стрелки на клавиатуре чтобы быстро листать анимации.");
                        player.SendChatMessage("Чтобы переключиться на определённую анимацию, используйте ~y~/animator skip [айди]~w~.");
                        player.SendChatMessage("~w~Помните, что некоторые анимации могут не применяться к игроку, либо");
                        player.SendChatMessage("применяться некорректно. За багаюз данных анимаций вы получите ~r~БЛОКИРОВКУ АККАУНТА~w~!");
                    }
                    if (action == "stop")
                    {
                        player.SendChatMessage("~b~[ANIMATOR]: ~w~AnimationManager был выключен.");
                        player.StopAnimation();
                    }
                }
                else
                {
                    player.SendChatMessage("~b~[ANIMATOR]: ~r~Сначала нужно прописать команду! ~y~/animator.");
                }
            }
        }

        public void SaveAnimatorData(Player player, string name)
        {
            if (Main.Players[player].AdminLVL < 9) return;
            string anim_group = player.GetData<string>("PLAYED_ANIMATION_GROUP");
            string anim_name = player.GetData<string>("PLAYED_ANIMATION_NAME");
            File.AppendAllText("Saved_Animations.txt", string.Format("{0}:          {1} {2}", name, anim_group, anim_name) + Environment.NewLine);
            player.SendChatMessage(string.Format("~b~[ANIMATOR]: ~w~Animation saved! Name: ~g~{0} ~w~Anim: ~y~{1} ~b~{2}", name, anim_group, anim_name));
            player.SendNotification("Saved animation as ~b~" + name + "!");
        }

        public void SkipAnimatorData(Player player, string animationID)
        {
            if (Main.Players[player].LVL < 5) return;
            int ID;
            if (Int32.TryParse(animationID, out ID))
            {
                int animations_amount = AnimatorList.animations.AllAnimations.Count - 1;
                if (ID > animations_amount || ID < 0)
                {
                    player.SendChatMessage("~b~[ANIMATOR]: ~w~ID должен быть между 0 и " + animations_amount + "!");
                    return;
                }
                player.TriggerEvent("SkipAnimatorData", ID);
            }
            else
            {
                player.SendChatMessage("~b~[ANIMATOR]: ~r~Неверный формат!");
            }
        }
	
	}
}